﻿using Telegram.Bot;

namespace SoundDeliveryBot.Core
{
    internal sealed class Bot
    {
        private readonly string token;
        private static TelegramBotClient botClient;

        public Bot(string token)
        {
            this.token = token;
        }

        public async void Start()
        {
            botClient = new TelegramBotClient(token);

            var messageHandler = new MessageHandler(botClient);

            botClient.OnMessage += messageHandler.OnMessage;

            await botClient.SetWebhookAsync("");
            botClient.StartReceiving();
        }

        public void Stop()
        {
            botClient.StopReceiving();
        }
    }
}
