﻿using Newtonsoft.Json;
using System.Collections.Generic;

namespace SoundDeliveryBot.Core.Coub
{
    [JsonObject]
    internal sealed class Coub
    {
        [JsonProperty(PropertyName = "title")]
        public string Title { get; set; }

        [JsonProperty(PropertyName = "permalink")]
        public string Permalink { get; set; }

        [JsonProperty(PropertyName = "duration")]
        public double Duration { get; set; }

        [JsonProperty(PropertyName = "tags")]
        public List<string> Tags { get; set; }

        [JsonProperty(PropertyName = "audio_url")]
        public string AudioURL { get; set; }

        [JsonProperty(PropertyName = "video_url")]
        public string VideoURL { get; set; }
    }
}
