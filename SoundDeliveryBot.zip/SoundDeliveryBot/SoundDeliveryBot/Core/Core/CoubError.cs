﻿using System.Text.Json.Serialization;

namespace SoundDeliveryBot.Core.Coub
{
    internal sealed class CoubError
    {
        internal sealed class ErrMessage
        {
            [JsonPropertyName("message")]
            public string Message { get; set; }

            [JsonPropertyName("coub_id")]
            public string CoubID { get; set; }

            [JsonPropertyName("timestamp")]
            public string Timestamp { get; set; }
        }

        public ErrMessage ErrorMessage { get; set; }
    }
}
