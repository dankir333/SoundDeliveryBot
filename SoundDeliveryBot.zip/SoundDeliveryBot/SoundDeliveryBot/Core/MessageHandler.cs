﻿using Telegram.Bot;
using Telegram.Bot.Args;

namespace SoundDeliveryBot.Core
{
    internal sealed class MessageHandler
    {
        private TelegramBotClient botClient;

        public MessageHandler(TelegramBotClient botClient)
        {
            this.botClient = botClient;
        }

        public async void OnMessage(object sender, MessageEventArgs e)
        {
            var message = e.Message;
            if (message == null && string.IsNullOrWhiteSpace(message.Text))
                return;

            switch (message.Text)
            {
                case "/start":
                    await Messenger.StartMessage(botClient, message.From.Id);
                    break;

                default:
                    var coubLink = message.Text;
                    await Messenger.SendCoub(coubLink.Substring(22), botClient, message.From.Id);
                    break;
            }
        }
    }
}
