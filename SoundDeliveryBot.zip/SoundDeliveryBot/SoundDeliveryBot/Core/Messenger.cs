﻿using SoundDeliveryBot.Utils;
using System;
using System.Threading.Tasks;
using Telegram.Bot;
using Telegram.Bot.Types;

namespace SoundDeliveryBot.Core
{
    internal sealed class Messenger
    {
        public static async Task StartMessage(TelegramBotClient botClient, ChatId chatID)
        {
            await botClient.SendTextMessageAsync(chatID, Settings.Config.StartMessage);
        }

        public static async Task SendCoub(string coubID, TelegramBotClient botClient, ChatId chatID)
        {
            var service = new SoundDeliveryService();

            var coub = service.GetCoub(coubID);

            var tags = "[";
            foreach (var tag in coub.Tags)
                tags += $"{tag}, ";

            tags = tags[0..^2];
            tags += "]";

            var description = $"Title: {coub.Title}\n" +
                $"ID: {coub.Permalink.Substring(22)}\n" +
                $"Tags: {tags}\n" +
                $"Duration: {TimeSpan.FromSeconds(coub.Duration):mm':'ss}";

            await botClient.SendTextMessageAsync(chatID, description);
            await botClient.SendVideoAsync(chatID, coub.VideoURL);
            await botClient.SendAudioAsync(chatID, coub.AudioURL);
        }

        public static async Task SendYouTube(string videoURL, TelegramBotClient botClient, ChatId chatID)
        {
            var service = new SoundDeliveryService();

            var video = service.GetYouTube(videoURL);

            await botClient.SendVideoAsync(chatID, video.VideoURL);
        }
    }
}
