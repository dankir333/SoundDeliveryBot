﻿using Newtonsoft.Json;
using SoundDeliveryBot.Utils;
using System.Net.Http;

namespace SoundDeliveryBot.Core
{
    internal sealed class SoundDeliveryService
    {
        private readonly HttpClient httpClient = new HttpClient();

        public Coub.Coub GetCoub(string coubID)
        {
            var uri = $"{Settings.Config.SoundDeliveryServiceBaseURL}/coub/{coubID}?content=full";

            var json = httpClient.GetStringAsync(uri).Result;
            var coub = JsonConvert.DeserializeObject<Coub.Coub>(json);
            return coub;
        }

        public YouTube.YouTube GetYouTube(string videoURL)
        {
            var uri = $"{Settings.Config.SoundDeliveryServiceBaseURL}/youtube?link={videoURL}";

            var json = httpClient.GetStringAsync(uri).Result;
            var video = JsonConvert.DeserializeObject<YouTube.YouTube>(json);
            return video;
        }
    }
}
