﻿using Newtonsoft.Json;

namespace SoundDeliveryBot.Core.YouTube
{
    [JsonObject]
    internal sealed class YouTube
    {
        [JsonProperty(PropertyName = "title")]
        public string Title { get; set; }

        [JsonProperty(PropertyName = "video_url")]
        public string VideoURL { get; set; }
    }
}
