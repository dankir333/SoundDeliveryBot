﻿using System.Text.Json.Serialization;

namespace SoundDeliveryBot.Core.YouTube
{
    internal sealed class YouTubeError
    {
        internal sealed class ErrMessage
        {
            [JsonPropertyName("message")]
            public string Message { get; set; }

            [JsonPropertyName("video_url")]
            public string CoubID { get; set; }

            [JsonPropertyName("timestamp")]
            public string Timestamp { get; set; }
        }

        public ErrMessage ErrorMessage { get; set; }
    }
}
