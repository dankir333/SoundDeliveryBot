﻿using System;
using SoundDeliveryBot.Core;
using SoundDeliveryBot.Utils;

namespace SoundDeliveryBot
{
    public sealed class Program
    {
        public static void Main()
        {
            Console.WriteLine("[Sound Delivery Bot] started. Enter '/exit' command to stop bot and exit.");

            var bot = new Bot(Settings.Config.Token);
            bot.Start();

            while (true)
            {
                Console.Write($"> ");
                var cmd = Console.ReadLine();

                if (cmd == "/exit")
                {
                    bot.Stop();
                    break;
                }
                else
                {
                    continue;
                }
            }

            Console.WriteLine("\n===== Press ENTER to exit =====");
            Console.ReadLine();
        }
    }
}
