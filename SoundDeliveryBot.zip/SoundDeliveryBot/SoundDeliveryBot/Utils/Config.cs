﻿using Newtonsoft.Json;
using System.IO;

namespace SoundDeliveryBot.Utils
{
    [JsonObject]
    internal sealed class Config
    {
        [JsonProperty(PropertyName = "token")]
        public string Token { get; set; }

        [JsonProperty(PropertyName = "start_message")]
        public string StartMessage { get; set; }

        [JsonProperty(PropertyName = "sound_delivery_service_base_url")]
        public string SoundDeliveryServiceBaseURL { get; set; }
    }

    internal static class Settings
    {
        public static Config Config { get; } = InstantiateConfig("config.json");

        private static Config InstantiateConfig(string path)
        {
            var json = File.ReadAllText(path);
            return JsonConvert.DeserializeObject<Config>(json);
        }
    }
}
